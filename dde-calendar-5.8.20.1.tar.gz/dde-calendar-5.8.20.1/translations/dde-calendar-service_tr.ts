<?xml version="1.0" ?><!DOCTYPE TS><TS language="tr" version="2.1">
<context>
    <name>JobRemindManager</name>
    <message>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="89"/>
        <source>One day before start</source>
        <translation>Başlamadan bir gün önce</translation>
    </message>
    <message>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="89"/>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="91"/>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="96"/>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="98"/>
        <source>Close</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="91"/>
        <source>Remind me tomorrow</source>
        <translation>Bana yarın hatırlat</translation>
    </message>
    <message>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="96"/>
        <source>Remind me later</source>
        <translation>Sonra hatırlat</translation>
    </message>
    <message>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="101"/>
        <source>Schedule Reminder</source>
        <translation>Zamanlamalı Hatırlatıcı</translation>
    </message>
    <message>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="191"/>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="200"/>
        <source>%1 to %2</source>
        <translation>%1 ile %2</translation>
    </message>
    <message>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="273"/>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="284"/>
        <source>Today</source>
        <translation>Bugün</translation>
    </message>
    <message>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="276"/>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="287"/>
        <source>Tomorrow</source>
        <translation>Yarın</translation>
    </message>
</context>
</TS>