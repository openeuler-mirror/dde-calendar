<?xml version="1.0" ?><!DOCTYPE TS><TS language="kab" version="2.1">
<context>
    <name>JobRemindManager</name>
    <message>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="89"/>
        <source>One day before start</source>
        <translation>Yiwen wass send beddu</translation>
    </message>
    <message>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="89"/>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="91"/>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="96"/>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="98"/>
        <source>Close</source>
        <translation>Mdel</translation>
    </message>
    <message>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="91"/>
        <source>Remind me tomorrow</source>
        <translation>Smekti-yi-d azekka</translation>
    </message>
    <message>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="96"/>
        <source>Remind me later</source>
        <translation>Smekti-yi-d ticki</translation>
    </message>
    <message>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="101"/>
        <source>Schedule Reminder</source>
        <translation>Asmekti s usɣiwes</translation>
    </message>
    <message>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="191"/>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="200"/>
        <source>%1 to %2</source>
        <translation>%1 ɣer %2</translation>
    </message>
    <message>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="273"/>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="284"/>
        <source>Today</source>
        <translation>Ass-a</translation>
    </message>
    <message>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="276"/>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="287"/>
        <source>Tomorrow</source>
        <translation>Azekka</translation>
    </message>
</context>
</TS>