<?xml version="1.0" ?><!DOCTYPE TS><TS language="sq" version="2.1">
<context>
    <name>JobRemindManager</name>
    <message>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="89"/>
        <source>One day before start</source>
        <translation>Një ditë para fillimit</translation>
    </message>
    <message>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="89"/>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="91"/>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="96"/>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="98"/>
        <source>Close</source>
        <translation>Mbylle</translation>
    </message>
    <message>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="91"/>
        <source>Remind me tomorrow</source>
        <translation>Kujtoma nesër</translation>
    </message>
    <message>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="96"/>
        <source>Remind me later</source>
        <translation>Kujtoma më vonë</translation>
    </message>
    <message>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="101"/>
        <source>Schedule Reminder</source>
        <translation>Kujtues Planesh</translation>
    </message>
    <message>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="191"/>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="200"/>
        <source>%1 to %2</source>
        <translation>%1 deri më %2</translation>
    </message>
    <message>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="273"/>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="284"/>
        <source>Today</source>
        <translation>Sot</translation>
    </message>
    <message>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="276"/>
        <location filename="../calendar-service/src/jobremindmanager.cpp" line="287"/>
        <source>Tomorrow</source>
        <translation>Nesër</translation>
    </message>
</context>
</TS>